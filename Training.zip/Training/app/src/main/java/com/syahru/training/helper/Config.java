package com.syahru.training.helper;

public final class Config {
    public static final String BUNDLE_ID = "string_extra_id";
    public static final String BUNDLE_NAMA = "string_extra_nama";
    public static final String BUNDLE_TIPE = "string_extra_tipe";
    public static final String BUNDLE_KUOTA = "string_extra_kuota";
    public static final String BUNDLE_HARGA = "string_extra_harga";
    public static final String BUNDLE_TANGGAL = "string_extra_tanggal";
    public static final String BUNDLE_STATUS = "string_extra_status";
    public static final String BUNDLE_IMAGE = "string_extra_image";
}
