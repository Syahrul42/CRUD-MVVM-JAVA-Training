package com.syahru.training.model;

import android.net.Uri;

import java.util.Collection;

public class TrainingModel {


    public int getNamaTraining() {
        return 0;
    }

    public int getTypeTraining() {
        return 0;
    }

    public int getJumlahTraining() {
        return 0;
    }

    public int getHargaTraining() {
        return 0;
    }

    public int getTanggalTraining() {
        return 0;
    }

    public Uri getGambarTraining() {
        return null;
    }


    public Collection getStatusTraining() {
        return null;
    }
}
